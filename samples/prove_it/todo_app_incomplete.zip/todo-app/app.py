from flask import Flask, request

app = Flask(__name__)
tasks = []  # TODO: save tasks per user


@app.route("/", methods=["GET", "POST"])
def index():
    if request.method == "POST":
        tasks.append(request.form["title"])
    items = "".join(f"<li>{t}</li>" for t in tasks)
    return f'<form method="post"><input name="title"><button>Add</button></form><ul>{items}</ul>'


# TODO: sign up and sign in


if __name__ == "__main__":
    app.run()
